package com.store.animals;

import java.awt.Color;
import java.awt.Container;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

public class Customer extends JFrame{
	public Customer(){
	getConnection();
		/*message();*/
	}
	private Connection ct; 
	private Statement sql;
	 public Connection getConnection() 
	    { 
	    	 try{
	 			Class.forName("com.mysql.jdbc.Driver");
	 			System.out.println("���ݿ��������سɹ�");
	 		}catch(ClassNotFoundException e){
	                e.printStackTrace();			
	 		}
	 		try{
	 			ct =DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
	 			System.out.println("���ݿ����ӳɹ�");
	 				 		}catch(SQLException e){
	 			e.printStackTrace();
	 		}
	       return ct; 
} 	
	private int id;//id
	private String iid;//����֤ID
	private int account;//�˺�money
	private String username;//����
	private String sex;//�Ա�
	private int phoneNumber;//�绰����
	private String Email;//����
	private Cart myCart;//���ﳵ	
	private JFrame customer=new JFrame();
	private JTextField t1=new JTextField();
	private JTextField t2=new JTextField();
	private JTextField t3=new JTextField();
	private JTextField t5=new JTextField();
	private JTextField t6=new JTextField();
	private JLabel j1=new JLabel();
	private JLabel j2=new JLabel();
	private JLabel j3=new JLabel();
	private JLabel j4=new JLabel();
	private JLabel j5=new JLabel();
	private JLabel j6=new JLabel();
	private JButton jb=new JButton();
	private JButton jb1=new JButton();
	public void message(){
	Container container = customer.getContentPane();//��ȡһ������  
	container.setLayout(null);//ʹ�ô���ȡ���ֲ�����������
	container.setBackground(Color.white);//���ñ�����ɫ
    customer.setSize(500,400);
    customer.setVisible(true);
    customer.setTitle("���Ƹ�����Ϣ");
    customer.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);//���ùرմ���ķ���
    j1.setForeground(Color.black);
    j1.setText("����֤��:");
    j1.setBounds(new Rectangle(50,0 ,70 ,30 ));
    container.add(j1);
    t1.setBounds(120,0, 250, 30);
    t1.setEditable(true);
    container.add(t1);
    j2.setForeground(Color.black);
    j2.setText("�˺�:");
    j2.setBounds(new Rectangle(50,60 ,50 ,30 ));
    container.add(j2);
    t2.setBounds(100, 60, 250, 30);
    t2.setEditable(true);
    container.add(t2);
    j3.setForeground(Color.black);
    j3.setText("����:");
    j3.setBounds(new Rectangle(50,120,50 ,30 ));
    container.add(j3);
    t3.setBounds(100,120, 250, 30);
    t3.setEditable(true);
    container.add(t3);
    j4.setForeground(Color.black);
    j4.setText("�Ա�:");
    j4.setBounds(new Rectangle(50,180,50 ,30 ));
    container.add(j4);
    ButtonGroup group=new ButtonGroup();
    JRadioButton jr1=new JRadioButton("��");
    JRadioButton jr2=new JRadioButton("Ů");
    jr1.setBounds(100,180, 50, 30);
    jr2.setBounds(170,180, 50, 30);
    group.add(jr2);
    group.add(jr1);
    container.add(jr1);
    container.add(jr2);
    j5.setForeground(Color.black);  
    j5.setText("�绰����:");
    j5.setBounds(new Rectangle(50,240,70,30 ));
    container.add(j5);
    t5.setBounds(120, 240, 250, 30);
    t5.setEditable(true);
    container.add(t5);
    j6.setForeground(Color.black);
    j6.setText("����:");
    j6.setBounds(new Rectangle(50,300,50 ,30 ));
    container.add(j6);
    t6.setBounds(100, 300, 250, 30);
    t6.setEditable(true);
    container.add(t6);
    jb.setText("����");
    jb.setBounds(300, 340,80,30);
    jb.setBackground(Color.lightGray);
    jb.setVisible(true);
    container.add(jb);
    jb.addActionListener(new ActionListener() {
    	public void actionPerformed(ActionEvent e){
    		try{
    			String iid=t1.getText();//��ȡ�û�����֤��
    		String account= t2.getText();//��ȡ�û��˻���
    		String username=t3.getText();//��ȡ�û�����
    		String sex="";
    		if(jr1.isSelected())
    		        {
    			sex="man";
    		        //��ȡ�û��Ա�
    		        }
    		if(jr2.isSelected())
    			  {
    			sex="woman";
    			  }
    	    String phoneNumber=t5.getText();//��ȡ�û��绰����
    		String Email=t6.getText();//��ȡ�����ı������������ 
    		sql=ct.createStatement();
    		String st1="insert into userinfo values(\""+iid+"\",\""+account+"\",\""+username+"\",\""+sex+"\",\""+phoneNumber+"\",\""+Email+"\")";
    		sql.executeUpdate(st1);	
    		JOptionPane.showMessageDialog(null,"����ɹ�");
          }catch(Exception e1){
	  	    	e1.printStackTrace();
  	      }
    	}
      
      });
    jb1.setText("����");
    jb1.setBounds(100,340,80,30);
    jb1.setBackground(Color.lightGray);
    jb1.setVisible(true);
    container.add(jb1);
    jb1.addActionListener(new ActionListener() {
    	public void actionPerformed(ActionEvent e){
    		customer.dispose();
    		Goods good=new Goods();
    		good.item();
    	}
      
      });
	}
	public int getId() {
		return id;
	}
	public void setId(int id){
		this.id=id;
	}
	public String getIid() {
		return iid;
	}
	public void setIid(String iid) {
		this.iid = iid;
	}
	public int getAccount() {
		return account;
	}
	public void setAccount(int account) {
		this.account = account;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public int getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public Cart getMyCart() {
		return myCart;
	}
	public void setMyCart(Cart myCart) {
		this.myCart = myCart;
	}
	 public ResultSet getlogin(String order) throws SQLException{
			try{
			    sql=ct.createStatement();//����Statement�����sql
			}catch(SQLException e){
				e.printStackTrace();
			}
			ResultSet resultSet =sql.executeQuery(order);//��ȡ��ѯ�����
			return resultSet;
			
		}
}
