package com.store.animals;

public class UserServiceImpl implements IUserService{


	/*
	@Override
	public boolean login(String name, String password) {
		// TODO Auto-generated method stub
		return false;
	}*/

	@Override
	public boolean register(Customer customer) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean checkMail(int uid, String email) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean logout(int id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getBackPwd(String email) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getBackPwd(int phoneNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean add(Customer e) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(int id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(Customer e) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean query(int id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean queryAll() {
		// TODO Auto-generated method stub
		return false;
	}

}
