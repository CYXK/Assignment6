package com.store.animals;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Set;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;

public class Goods extends JFrame{
	private int id;
	private Pet pet;
	private int number;
	private float price;
	private int inventory;
	private Set<Comment> comments;
	private JFrame jfr=new JFrame();
	private JTextArea jtf  =new JTextArea();//�����ı������
	private JTextArea jtf1  =new JTextArea();
	private JTextArea jtf2 =new JTextArea();
	private JTextArea jtf3  =new JTextArea();
	private JTextArea jtf4 =new JTextArea();
	private JTextArea jtf5  =new JTextArea();
	private JTextArea jtf6  =new JTextArea();
	private JTextArea jtf7  =new JTextArea();
	private JTextArea jtf8  =new JTextArea();
	private JTextArea jtf9  =new JTextArea();
	private JTextArea jtf10  =new JTextArea();
	private JTextArea jtf11  =new JTextArea();
	private JButton jta  =new JButton();
	private JButton jta1 =new JButton();
	private JButton jta2 =new JButton();
	private JButton jta3  =new JButton();
	private JButton jta4  =new JButton();
	private JButton jta5  =new JButton();
	private JButton jta6  =new JButton();
	private JButton jta7  =new JButton();
	private JButton jta8  =new JButton();
	private JButton jta9  =new JButton();
	private JButton jta10  =new JButton();
	private JButton jta11  =new JButton();
	private JButton b1=new JButton();
	private JButton b2=new JButton();
	private JButton b3=new JButton();
	private JButton b4=new JButton();
	private JButton b5=new JButton();
	private JButton b6=new JButton();
	private JButton b7=new JButton();
	private JButton b8=new JButton();
	private JButton b9=new JButton();
	private JButton b10=new JButton();
	private JButton b11=new JButton();
	private JButton b12=new JButton();
	private JButton b0=new JButton();
	private JLabel a1=new JLabel();
	private login data=new login();
	private ArrayList<Pet> d=new ArrayList<Pet>();	
	private ArrayList<Pet> d1=new ArrayList<Pet>();
	private ArrayList<Pet> d2=new ArrayList<Pet>();
	private ArrayList<Pet> d3=new ArrayList<Pet>();
	private ArrayList<Pet> d4=new ArrayList<Pet>();
	private ArrayList<Pet> d5=new ArrayList<Pet>();
	private ArrayList<Pet> d6=new ArrayList<Pet>();
	private ArrayList<Pet> d7=new ArrayList<Pet>();
	private ArrayList<Pet> d8=new ArrayList<Pet>();
	private ArrayList<Pet> d9=new ArrayList<Pet>();
	private ArrayList<Pet> d10=new ArrayList<Pet>();
	private ArrayList<Pet> d11=new ArrayList<Pet>();
	public Goods(){
		output();
		information();
	}
	public void item(){
		Container container = jfr.getContentPane();//��ȡһ������  
		container.setLayout(null);//ʹ�ô���ȡ���ֲ�����������
		container.setBackground(Color.white);//���ñ�����ɫ
		jfr.setSize(1000, 1000);
        jfr.setVisible(true);
        jfr.setTitle("�����=���أ�=");
        jfr.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);//���ùرմ���ķ���
        ImageIcon img = new ImageIcon("1.jpg");// ���Ǳ���ͼƬ
	    JLabel imgLabel = new JLabel(img);// ������ͼ���ڱ�ǩ�
	    jfr.getLayeredPane().add(imgLabel, new Integer(Integer.MIN_VALUE));
	    imgLabel.setBounds(0, 0, jfr.getWidth(), jfr.getHeight());// ���ñ�����ǩ��λ��
	    ((JPanel) container).setOpaque(false); //ʹ�ñ���ͼƬ�ɼ����ñ�ǩΪ��͸��״̬
        jtf.setBounds(80,70,150,160);
        jtf.setVisible(true);
        
        jtf.setBackground(Color.pink);
       container.add(jtf);
       jta.setBounds(125,235,60,20);
       jta.setVisible(true);
       jta.setText("����");
       jta.setBackground(Color.lightGray);
       container.add(jta);
       jta.addActionListener(new ActionListener() {
    		public void actionPerformed(ActionEvent e){
    	    	  jfr.dispose();
    	    	  Comment cm=new Comment();
    	    	  cm.dog();
    	      }
    	  
    	  });
       jta1.setBounds(355,235,60,20);
       jta1.setVisible(true);
       jta1.setText("����");
       jta1.setBackground(Color.lightGray);
       container.add(jta1);
       jta1.addActionListener(new ActionListener() {
   		public void actionPerformed(ActionEvent e){
   	    	  jfr.dispose();
   	    	  Comment cm=new Comment();
   	    	  cm.cat();
   	      }
   	  
   	  });
       jta2.setBounds(585,235,60,20);
       jta2.setVisible(true);
       jta2.setText("����");
       jta2.setBackground(Color.lightGray);
       container.add(jta2);
       jta2.addActionListener(new ActionListener() {
   		public void actionPerformed(ActionEvent e){
   	    	  jfr.dispose();
   	    	  Comment cm=new Comment();
   	    	  cm.turtle();
   	      }
   	  
   	  });
       jta3.setBounds(815,235,60,20);
       jta3.setVisible(true);
       jta3.setText("����");
       jta3.setBackground(Color.lightGray);
       container.add(jta3);
       jta3.addActionListener(new ActionListener() {
   		public void actionPerformed(ActionEvent e){
   	    	  jfr.dispose();
   	    	  Comment cm=new Comment();
   	    	  cm.parrot();
   	      }
   	  
   	  });
       jta4.setBounds(125,465,60,20);
       jta4.setVisible(true);
       jta4.setText("����");
       jta4.setBackground(Color.lightGray);
       container.add(jta4);
       jta4.addActionListener(new ActionListener() {
   		public void actionPerformed(ActionEvent e){
   	    	  jfr.dispose();
   	    	  Comment cm=new Comment();
   	    	  cm.hamster();
   	      }
   	  
   	  });
       jta5.setBounds(355,465,60,20);
       jta5.setVisible(true);
       jta5.setText("����");
       jta5.setBackground(Color.lightGray);
       container.add(jta5);
       jta5.addActionListener(new ActionListener() {
   		public void actionPerformed(ActionEvent e){
   	    	  jfr.dispose();
   	    	  Comment cm=new Comment();
   	    	  cm.squirrel();
   	      }
   	  
   	  });
       jta6.setBounds(585,465,60,20);
       jta6.setVisible(true);
       jta6.setText("����");
       jta6.setBackground(Color.lightGray);
       container.add(jta6);
       jta6.addActionListener(new ActionListener() {
   		public void actionPerformed(ActionEvent e){
   	    	  jfr.dispose();
   	    	  Comment cm=new Comment();
   	    	  cm.rabbit();
   	      }
   	  
   	  });
       jta7.setBounds(815,465,60,20);
       jta7.setVisible(true);
       jta7.setText("����");
       jta7.setBackground(Color.lightGray);
       container.add(jta7);
       jta7.addActionListener(new ActionListener() {
   		public void actionPerformed(ActionEvent e){
   	    	  jfr.dispose();
   	    	  Comment cm=new Comment();
   	    	  cm.snake();
   	      }
   	  
   	  });
       jta8.setBounds(125,695,60,20);
       jta8.setVisible(true);
       jta8.setText("����");
       jta8.setBackground(Color.lightGray);
       container.add(jta8);
       jta8.addActionListener(new ActionListener() {
   		public void actionPerformed(ActionEvent e){
   	    	  jfr.dispose();
   	    	  Comment cm=new Comment();
   	    	  cm.lizard();
   	      }
   	  
   	  });
       jta9.setBounds(355,695,60,20);
       jta9.setVisible(true);
       jta9.setText("����");
       jta9.setBackground(Color.lightGray);
       container.add(jta9);
       jta9.addActionListener(new ActionListener() {
   		public void actionPerformed(ActionEvent e){
   	    	  jfr.dispose();
   	    	  Comment cm=new Comment();
   	    	  cm.fish();
   	      }
   	  
   	  });
       jta10.setBounds(585,695,60,20);
       jta10.setVisible(true);
       jta10.setText("����");
       jta10.setBackground(Color.lightGray);
       container.add(jta10);
       jta10.addActionListener(new ActionListener() {
   		public void actionPerformed(ActionEvent e){
   	    	  jfr.dispose();
   	    	  Comment cm=new Comment();
   	    	  cm.myna();
   	      }
   	  
   	  });
       jta11.setBounds(815,695,60,20);
       jta11.setVisible(true);
       jta11.setText("����");
       jta11.setBackground(Color.lightGray);
       container.add(jta11);
       jta11.addActionListener(new ActionListener() {
   		public void actionPerformed(ActionEvent e){
   	    	  jfr.dispose();
   	    	  Comment cm=new Comment();
   	    	  cm.canary();
   	      }
   	  
   	  });
       
       a1.setFont(new java.awt.Font("����", Font.PLAIN, 25));
	    a1.setText("Animals(* ��3)(�ţ� *)");
	    a1.setBounds(new Rectangle(350, 10, 300, 50));
	    a1.setVisible(true);
	    container.add(a1);
	    a1.setHorizontalAlignment(SwingConstants.CENTER);//�������ַ����ڱ�ǩ���м�
       jtf1.setBounds(310,70,150,160);
       jtf1.setVisible(true);
       jtf1.setBackground(Color.pink);
      container.add(jtf1);
      jtf2.setBounds(540,70,150,160);
      jtf2.setVisible(true);
      jtf2.setBackground(Color.pink);
     container.add(jtf2);
     jtf3.setBounds(770,70,150,160);
     jtf3.setVisible(true);
     jtf3.setBackground(Color.pink);
    container.add(jtf3);
    jtf4.setBounds(80,300,150,160);
    jtf4.setVisible(true);
    jtf4.setBackground(Color.pink);
   container.add(jtf4);
   jtf5.setBounds(310,300,150,160);
   jtf5.setVisible(true);
   jtf5.setBackground(Color.pink);
  container.add(jtf5);
  jtf6.setBounds(540,300,150,160);
  jtf6.setVisible(true);
  jtf6.setBackground(Color.pink);
 container.add(jtf6);
 jtf7.setBounds(770,300,150,160);
 jtf7.setVisible(true);
 jtf7.setBackground(Color.pink);
container.add(jtf7);
jtf8.setBounds(80,530,150,160);
jtf8.setVisible(true);
jtf8.setBackground(Color.pink);
container.add(jtf8);
jtf9.setBounds(310,530,150,160);
jtf9.setVisible(true);
jtf9.setBackground(Color.pink);
container.add(jtf9);
jtf10.setBounds(540,530,150,160);
jtf10.setVisible(true);
jtf10.setBackground(Color.pink);
container.add(jtf10);
jtf11.setBounds(770,530,150,160);
jtf11.setVisible(true);
jtf11.setBackground(Color.pink);
container.add(jtf11);
//����
jtf.setLineWrap(true);
jtf1.setLineWrap(true);
jtf2.setLineWrap(true);
jtf3.setLineWrap(true);
jtf4.setLineWrap(true);
jtf5.setLineWrap(true);
jtf6.setLineWrap(true);
jtf7.setLineWrap(true);
jtf8.setLineWrap(true);
jtf9.setLineWrap(true);
jtf10.setLineWrap(true);
jtf11.setLineWrap(true);
//���в�����
jtf.setWrapStyleWord(true);
jtf1.setWrapStyleWord(true);
jtf2.setWrapStyleWord(true);
jtf3.setWrapStyleWord(true);
jtf4.setWrapStyleWord(true);
jtf5.setWrapStyleWord(true);
jtf6.setWrapStyleWord(true);
jtf7.setWrapStyleWord(true);
jtf8.setWrapStyleWord(true);
jtf9.setWrapStyleWord(true);
jtf10.setWrapStyleWord(true);
jtf11.setWrapStyleWord(true);
jtf.setEditable(false);
jtf1.setEditable(false);
jtf2.setEditable(false);
jtf3.setEditable(false);
jtf4.setEditable(false);
jtf5.setEditable(false);
jtf6.setEditable(false);
jtf7.setEditable(false);
jtf8.setEditable(false);
jtf9.setEditable(false);
jtf10.setEditable(false);
jtf11.setEditable(false);
b0.setBounds(750,20,200,30);
b0.setVisible(true);
b0.setBackground(Color.lightGray);
b0.setText("�����û�������Ϣ");
container.add(b0);
b0.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e){
    	  jfr.dispose();
    	  Customer p=new Customer();
    	  p.message();
      }
  
  });
b1.setBounds(115,270,80,30);
b1.setVisible(true);
b1.setBackground(Color.lightGray);
b1.setText("����");
container.add(b1);
b1.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e){
    	  jfr.dispose();
    	  Cart cart=new Cart();
    	  cart.car();
      }
  
  });
b2.setBounds(345,270,80,30);
b2.setVisible(true);
b2.setBackground(Color.lightGray);
b2.setText("����");
container.add(b2);
b2.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e){
    	  jfr.dispose();
    	  Cart cart=new Cart();
    	  cart.car();
      }
  
  });
b3.setBounds(575,270,80,30);
b3.setVisible(true);
b3.setBackground(Color.lightGray);
b3.setText("����");
container.add(b3);
b3.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e){
    	  jfr.dispose();
    	  Cart cart=new Cart();
    	  cart.car();
      }
  
  });
b4.setBounds(805,270,80,30);
b4.setVisible(true);
b4.setBackground(Color.lightGray);
b4.setText("����");
container.add(b4);
b4.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e){
    	  jfr.dispose();
    	  Cart cart=new Cart();
    	  cart.car();
      }
  
  });
b5.setBounds(115,500,80,30);
b5.setVisible(true);
b5.setBackground(Color.lightGray);
b5.setText("����");
container.add(b5);
b5.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e){
    	  jfr.dispose();
    	  Cart cart=new Cart();
    	  cart.car();
      }
  
  });
b6.setBounds(345,500,80,30);
b6.setVisible(true);
b6.setBackground(Color.lightGray);
b6.setText("����");
container.add(b6);
b6.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e){
    	  jfr.dispose();
    	  Cart cart=new Cart();
    	  cart.car();
      }
  
  });
b7.setBounds(575,500,80,30);
b7.setVisible(true);
b7.setBackground(Color.lightGray);
b7.setText("����");
container.add(b7);
b7.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e){
    	  jfr.dispose();
    	  Cart cart=new Cart();
    	  cart.car();
      }
  
  });
b8.setBounds(805,500,80,30);
b8.setVisible(true);
b8.setBackground(Color.lightGray);
b8.setText("����");
container.add(b8);
b8.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e){
    	  jfr.dispose();
    	  Cart cart=new Cart();
    	  cart.car();
      }
  
  });
b9.setBounds(115,730,80,30);
b9.setVisible(true);
b9.setBackground(Color.lightGray);
b9.setText("����");
container.add(b9);
b9.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e){
    	  jfr.dispose();
    	  Cart cart=new Cart();
    	  cart.car();
      }
  
  });
b10.setBounds(345,730,80,30);
b10.setVisible(true);
b10.setBackground(Color.lightGray);
b10.setText("����");
container.add(b10);
b10.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e){
    	  jfr.dispose();
    	  Cart cart=new Cart();
    	  cart.car();
      }
  
  });
b11.setBounds(575,730,80,30);
b11.setVisible(true);
b11.setBackground(Color.lightGray);
b11.setText("����");
container.add(b11);
b11.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e){
    	  jfr.dispose();
    	  Cart cart=new Cart();
    	  cart.car();
      }
  
  });
b12.setBounds(805,730,80,30);
b12.setVisible(true);
b12.setBackground(Color.lightGray);
b12.setText("����");
container.add(b12);
b12.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e){
    	  jfr.dispose();
    	  Cart cart=new Cart();
    	  cart.car();
      }
  
  });
	}
	public void information(){
		d.clear();//��ն�̬����
		d1.clear();
		data.getConnection();
		 try{
	        	String pi4 ="select*from pet where name like 'dog'";
				ResultSet a=data.getlogin(pi4);
				while(a.next()){
					Pet pi1=new Pet();
					pi1.setId(a.getInt(1));
					pi1.setName(a.getString("name"));//����õ����ݽ��д���
					pi1.setEat(a.getString("eat"));
					pi1.setDrink(a.getString("drink"));
					pi1.setLive(a.getString("live"));
					pi1.setHobby(a.getString("hobby"));
					d.add(pi1);}
					String pi41 ="select*from pet where name like 'cat'";
					ResultSet b=data.getlogin(pi41);
					while(b.next()){
						Pet pi2=new Pet();
						pi2.setId(b.getInt(1));
						pi2.setName(b.getString("name"));//����õ����ݽ��д���
						pi2.setEat(b.getString("eat"));
						pi2.setDrink(b.getString("drink"));
						pi2.setLive(b.getString("live"));	
						pi2.setHobby(b.getString("hobby"));
						d1.add(pi2);
						}
						String pi42 ="select*from pet where name like 'turtle'";
						ResultSet f=data.getlogin(pi42);
						while(f.next()){
							Pet p3=new Pet();
							p3.setId(f.getInt(1));
							p3.setName(f.getString("name"));//����õ����ݽ��д���
							p3.setEat(f.getString("eat"));
							p3.setDrink(f.getString("drink"));
					        p3.setLive(f.getString("live"));	
							p3.setHobby(f.getString("hobby"));
							d2.add(p3);
		 }
						String z ="select*from pet where name like 'parrot'";
						ResultSet set=data.getlogin(z);
						while(set.next()){
							Pet p1=new Pet();
							p1.setId(set.getInt(1));
							p1.setName(set.getString("name"));//����õ����ݽ��д���
							p1.setEat(set.getString("eat"));
							p1.setDrink(set.getString("drink"));
							p1.setLive(set.getString("live"));	
							p1.setHobby(set.getString("hobby"));
							d3.add(p1);
							}
						String z1 ="select*from pet where name like 'hamster'";
						ResultSet set1=data.getlogin(z1);
						while(set1.next()){
							Pet p11=new Pet();
							p11.setId(set1.getInt(1));
							p11.setName(set1.getString("name"));//����õ����ݽ��д���
							p11.setEat(set1.getString("eat"));
							p11.setDrink(set1.getString("drink"));
							p11.setLive(set1.getString("live"));	
							p11.setHobby(set1.getString("hobby"));
							d4.add(p11);
							}
						String z2 ="select*from pet where name like 'canary'";
						ResultSet set11=data.getlogin(z2);
						while(set11.next()){
							Pet p12=new Pet();
							p12.setId(set11.getInt(1));
							p12.setName(set11.getString("name"));//����õ����ݽ��д���
							p12.setEat(set11.getString("eat"));
							p12.setDrink(set11.getString("drink"));
							p12.setLive(set11.getString("live"));	
							p12.setHobby(set11.getString("hobby"));
							d5.add(p12);
							}
						String z3 ="select*from pet where name like 'squirrel'";
						ResultSet set12=data.getlogin(z3);
						while(set12.next()){
							Pet p13=new Pet();
							p13.setId(set12.getInt(1));
							p13.setName(set12.getString("name"));//����õ����ݽ��д���
							p13.setEat(set12.getString("eat"));
							p13.setDrink(set12.getString("drink"));
							p13.setLive(set12.getString("live"));	
							p13.setHobby(set12.getString("hobby"));
							d6.add(p13);
							}
						String z4 ="select*from pet where name like 'rabbit'";
						ResultSet set13=data.getlogin(z4);
						while(set13.next()){
							Pet p14=new Pet();
							p14.setId(set13.getInt(1));
							p14.setName(set13.getString("name"));//����õ����ݽ��д���
							p14.setEat(set13.getString("eat"));
							p14.setDrink(set13.getString("drink"));
							p14.setLive(set13.getString("live"));	
							p14.setHobby(set13.getString("hobby"));
							d7.add(p14);
							}
						String z5 ="select*from pet where name like 'snake'";
						ResultSet set14=data.getlogin(z5);
						while(set14.next()){
							Pet p15=new Pet();
							p15.setId(set14.getInt(1));
							p15.setName(set14.getString("name"));//����õ����ݽ��д���
							p15.setEat(set14.getString("eat"));
							p15.setDrink(set14.getString("drink"));
							p15.setLive(set14.getString("live"));	
							p15.setHobby(set14.getString("hobby"));
							d8.add(p15);
							}
						String z6 ="select*from pet where name like 'lizard'";
						ResultSet set15=data.getlogin(z6);
						while(set15.next()){
							Pet p16=new Pet();
							p16.setId(set15.getInt(1));
							p16.setName(set15.getString("name"));//����õ����ݽ��д���
							p16.setEat(set15.getString("eat"));
							p16.setDrink(set15.getString("drink"));
							p16.setLive(set15.getString("live"));	
							p16.setHobby(set15.getString("hobby"));
							d9.add(p16);
							}
						String z7 ="select*from pet where name like 'fish'";
						ResultSet set16=data.getlogin(z7);
						while(set16.next()){
							Pet p17=new Pet();
							p17.setId(set16.getInt(1));
							p17.setName(set16.getString("name"));//����õ����ݽ��д���
							p17.setEat(set16.getString("eat"));
							p17.setDrink(set16.getString("drink"));
							p17.setLive(set16.getString("live"));	
							p17.setHobby(set16.getString("hobby"));
							d10.add(p17);
							}
						String z8 ="select*from pet where name like 'myna'";
						ResultSet set17=data.getlogin(z8);
						while(set17.next()){
							Pet p18=new Pet();
							p18.setId(set17.getInt(1));
							p18.setName(set17.getString("name"));//����õ����ݽ��д���
							p18.setEat(set17.getString("eat"));
							p18.setDrink(set17.getString("drink"));
							p18.setLive(set17.getString("live"));	
							p18.setHobby(set17.getString("hobby"));
							d11.add(p18);
							}
				
						}catch(Exception e){
			 e.printStackTrace();
		 }
		 output();
	 }
	public void output(){
		
		for(Pet pi3:d){
		
			jtf.append(pi3.getId()+"\n"+pi3.getName()+" \n"+pi3.getEat()+"\n\n"+pi3.getDrink()+"\n\n"+pi3.getLive()+"\n\n"+pi3.getHobby());
				}
		for(Pet pi31:d1){
				jtf1.append(pi31.getId()+"\n"+pi31.getName()+" \n"+pi31.getEat()+"\n\n"+pi31.getDrink()+"\n\n"+pi31.getLive()+"\n\n"+pi31.getHobby());
		}
		for(Pet pi32:d2){
			jtf2.append(pi32.getId()+"\n"+pi32.getName()+" \n"+pi32.getEat()+"\n\n"+pi32.getDrink()+"\n\n"+pi32.getLive()+"\n\n"+pi32.getHobby());
	}
		for(Pet pi33:d3){
			jtf3.append(pi33.getId()+"\n"+pi33.getName()+" \n"+pi33.getEat()+"\n\n"+pi33.getDrink()+"\n\n"+pi33.getLive()+"\n\n"+pi33.getHobby());
	}
		for(Pet pi34:d4){
			jtf4.append(pi34.getId()+"\n"+pi34.getName()+" \n"+pi34.getEat()+"\n\n"+pi34.getDrink()+"\n\n"+pi34.getLive()+"\n\n"+pi34.getHobby());
	}
		for(Pet pi35:d5){
			jtf11.append(pi35.getId()+"\n"+pi35.getName()+" \n"+pi35.getEat()+"\n\n"+pi35.getDrink()+"\n\n"+pi35.getLive()+"\n\n"+pi35.getHobby());
	}
		for(Pet pi36:d6){
			jtf5.append(pi36.getId()+"\n"+pi36.getName()+" \n"+pi36.getEat()+"\n\n"+pi36.getDrink()+"\n\n"+pi36.getLive()+"\n\n"+pi36.getHobby());
	}
		for(Pet pi37:d7){
			jtf6.append(pi37.getId()+"\n"+pi37.getName()+" \n"+pi37.getEat()+"\n\n"+pi37.getDrink()+"\n\n"+pi37.getLive()+"\n\n"+pi37.getHobby());
	}
		for(Pet pi38:d8){
			jtf7.append(pi38.getId()+"\n"+pi38.getName()+" \n"+pi38.getEat()+"\n\n"+pi38.getDrink()+"\n\n"+pi38.getLive()+"\n\n"+pi38.getHobby());
	}
		for(Pet pi39:d9){
			jtf8.append(pi39.getId()+"\n"+pi39.getName()+" \n"+pi39.getEat()+"\n\n"+pi39.getDrink()+"\n\n"+pi39.getLive()+"\n\n"+pi39.getHobby());
	}
		for(Pet pi310:d10){
			jtf9.append(pi310.getId()+"\n"+pi310.getName()+" \n"+pi310.getEat()+"\n\n"+pi310.getDrink()+"\n\n"+pi310.getLive()+"\n\n"+pi310.getHobby());
	}
		for(Pet pi311:d11){
			jtf10.append(pi311.getId()+"\n"+pi311.getName()+" \n"+pi311.getEat()+"\n\n"+pi311.getDrink()+"\n\n"+pi311.getLive()+"\n\n"+pi311.getHobby());
	}
	}
	public int getId() {
		return id;
	}
	public void setId(int id){
		this.id=id;
	}
	public Pet getPet() {
		return pet;
	}
	public void setPet(Pet pet) {
		this.pet = pet;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public int getInventory() {
		return inventory;
	}
	public void setInventory(int inventory) {
		this.inventory = inventory;
	}
	public Set<Comment> getComments() {
		return comments;
	}
	public void setComments(Set<Comment> comments) {
		this.comments = comments;
	}

}
