package com.store.animals;

public interface IUserService extends IBaseService<Customer>{
	/*public boolean login(String name,String password);*/
	public boolean register(Customer customer);
	public boolean checkMail(int uid,String email);
	public boolean logout(int id);
	public String getBackPwd(String email);
	public String getBackPwd(int phoneNumber);
}
