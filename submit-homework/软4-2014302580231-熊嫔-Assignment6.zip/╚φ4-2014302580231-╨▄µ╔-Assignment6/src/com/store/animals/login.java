package com.store.animals;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import javax.swing.JPanel;
public class login extends JFrame {
	public login() {	
	  }

	private JFrame frm=new JFrame();//����JFrame����
	private Connection ct ; 
	private Statement sql;
	private ResultSet rs;
	 public Connection getConnection() 
	    { 
	    	 try{
	 			Class.forName("com.mysql.jdbc.Driver");
	 			System.out.println("���ݿ��������سɹ�");
	 		}catch(ClassNotFoundException e){
	                e.printStackTrace();			
	 		}
	 		try{
	 			ct =DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
	 			System.out.println("���ݿ����ӳɹ�");
	 				 		}catch(SQLException e){
	 			e.printStackTrace();
	 		}
	       return ct; 
 } 	  	
	 
	private JTextField jTextField1  =new JTextField();//�����ı������
	private JLabel jLabel1 = new JLabel();
	private JLabel jLabel2 = new JLabel();
	private JLabel jLabel3 = new JLabel();
    private JButton jButton1 = new JButton();
	private JButton jButton2 = new JButton();
	private JButton jButton3=new JButton();
	private JButton jButton4=new JButton();
	private JPasswordField jPasswordField1 = new JPasswordField();

public static void main(String[] args)
	  {
	login b=new login();//����
	b.jbInit();
	b.getConnection();

 }
public void jbInit(){
		Container container = frm.getContentPane();//��ȡһ������  
		container.setLayout(null);//ʹ�ô���ȡ���ֲ�����������
		container.setBackground(Color.white);//���ñ�����ɫ
	    frm.setSize(500,400);
	    frm.setVisible(true);
	    frm.setTitle("��ӭע���¼=���أ�=");
	    frm.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);//���ùرմ���ķ���
	    ImageIcon img = new ImageIcon("5.jpg");// ���Ǳ���ͼƬ
	    JLabel imgLabel = new JLabel(img);// ������ͼ���ڱ�ǩ�
	    frm.getLayeredPane().add(imgLabel, new Integer(Integer.MIN_VALUE));
	    imgLabel.setBounds(0, 0, frm.getWidth(), frm.getHeight());// ���ñ�����ǩ��λ��
	    ((JPanel) container).setOpaque(false); //ʹ�ñ���ͼƬ�ɼ����ñ�ǩΪ��͸��״̬
	    jLabel1.setForeground(Color.black);
	    jLabel1.setText("�û���");
	    jLabel1.setBounds(new Rectangle(50, 100, 68, 29));
	    jButton2.setBounds(new Rectangle(260, 300, 100, 30));
	    jButton2.setText("���");
	    jButton2.addActionListener(new ActionListener() {
	     public void actionPerformed(ActionEvent e) {
	            	jTextField1.setText("");//���ı����ÿ�
	            	jTextField1.requestFocus();//����ص��ı���
	            	jPasswordField1.setText("");//��������ÿ�
	            	jPasswordField1.requestFocus();//����ص������
	            }
	        });
	        jButton3.setText("�˳�");
	        jButton3.setBounds(new Rectangle(380, 300, 100, 30));
	        jButton3.addActionListener(new ActionListener() {
	  	      public void actionPerformed(ActionEvent e){
	  	    	  System.exit(0);
	  	      }
	        });	        
	        jButton4.setText("ע��");
	        jButton4.setBounds(new Rectangle(140, 300, 100, 30));
	        jButton4.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e){
		  	    	  try{	
		  	    		sql=ct.createStatement();
		  	    		  String st="insert into 2014302580231_user values(\""+8+"\",\""+jTextField1.getText()+"\",\""+jPasswordField1.getText()+"\")";
		  	    		 sql.executeUpdate(st);	  	    		
		             JOptionPane.showMessageDialog(null, "ע��ɹ�");
		  	      }catch(Exception e1){
		  	    	e1.printStackTrace();
		  	      }
		  	      }
		        });
	    jButton1.setBounds(new Rectangle(20, 300,100 , 30));
	    jButton1.setText("��¼");
	    jButton1.addActionListener(new ActionListener() {
	      public void actionPerformed(ActionEvent e) {
	    	  login d=new login();
	  	    ct=d.getConnection();
	  	        //�ж��û����Ƿ�Ϊ��
	  	     if (jTextField1.getText().length() == 0) {
	  	          JOptionPane.showMessageDialog(null,"�û���Ϊ�գ��������û�����ע��");
	  	        }
	  	    //�ж������Ƿ�Ϊ��
	  	       else 
	  	    	   if (jPasswordField1.getText().length()==0)
	  	        {
	  	    		   JOptionPane.showMessageDialog(null,"����Ϊ�գ�����������");
	  	       }
	  	       else
	  	       {
	  	          try
	  	          {
	  	        	  sql=ct.createStatement();
	  	      	    rs=sql.executeQuery("select * from 2014302580231_user where username='"+jTextField1.getText()+"' and password='"+jPasswordField1.getText()+"'");                                     
	  	              if (rs.next())
	  	              {
	  	                  if(jPasswordField1.getText().equals(rs.getString("password")))
	  	                  {
	  	                 	  frm.dispose();
	    	                   Goods g=new Goods();	  	   
	    	                   g.item();
	  	                 }
	  	                 else
	  	                 {
	  	                	 JOptionPane.showMessageDialog(null,"�������");
	  	                 }
	  	              }
	  	              else
	  	              {
	  	            	  JOptionPane.showMessageDialog(null,"�û���������");
	  	              }	  	             	  	              

	  	}
	  	          catch(Exception c){
	  	             JOptionPane.showMessageDialog(null, "�������ݿ�ʧ��");
	  	                             }
	  	       }	    
	    	
	      }
	    });
	    jTextField1.setBounds(new Rectangle(109, 100, 136, 23));
	    jPasswordField1.setBounds(new Rectangle(109, 200, 136, 23));
	    container.add(jLabel1);
	    jLabel3.setFont(new java.awt.Font("����", Font.PLAIN, 24));
	    jLabel3.setText("С�ܵĳ����̵�ע��&��¼");
	    jLabel3.setBounds(new Rectangle(75, 15, 350, 47));
	    jLabel3.setHorizontalAlignment(SwingConstants.CENTER);//�������ַ����ڱ�ǩ���м�
	   container.add(jTextField1);
	   container.add(jLabel2);
       container.add(jButton2);
	   container.add(jButton1);
	   container.add(jButton3);
	   container.add(jButton4);
	  container.add(jLabel3);
	   container.add(jPasswordField1);
	    jLabel2.setForeground(Color.black);
	    jLabel2.setText("����");
	    jLabel2.setBounds(new Rectangle(50, 200, 68, 29));
	  }
	 public ResultSet getlogin(String order) throws SQLException{
			try{
			    sql=ct.createStatement();//����Statement�����sql
			}catch(SQLException e){
				e.printStackTrace();
			}
			ResultSet resultSet =sql.executeQuery(order);//��ȡ��ѯ�����
			return resultSet;
			
		}

}
