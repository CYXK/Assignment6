package com.store.animals;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
public class Cart {
	private int id;
	private Map<Integer,Integer> list;//(id,number)
	private final int WIDTH=500;
	private	final int HEIGHT=400;
	private	JFrame jf=new JFrame();
	private	 JToggleButton jt_plus=new JToggleButton("+");
	private	 JToggleButton jt_dec=new JToggleButton("-");
	private	 JTextField jt=new JTextField();
	private	 JTextField jt1=new JTextField();
	private	 JTextField jt2=new JTextField();
	private	 JTextField jt3=new JTextField();
	private JLabel jLabel1 = new JLabel();
	private JLabel jLabel2 = new JLabel();
	private JLabel jLabel3 = new JLabel();
	private JLabel jLabel4 =new JLabel();
    public void car(){
    	Container container = jf.getContentPane();//获取一个容器  
		container.setLayout(null);//使该窗体取消局部管理器设置
		container.setBackground(Color.white);//设置背景颜色
		jf.setVisible(true);
		 jf.setSize(WIDTH, HEIGHT);
		 jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		 jf.setTitle("购物车");
		 jLabel1.setBounds(30, 20,120,30);
		 jLabel1.setForeground(Color.black);
		 jLabel1.setText("Input good's id:");
		 container.add(jLabel1);
		 jLabel2.setBounds(30,80,120,30);
		 jLabel2.setForeground(Color.black);
		 jLabel2.setText("Input good's number:");
		 container.add(jLabel2);
		 jLabel3.setBounds(30,140,120,30);
		 jLabel3.setForeground(Color.black);
		 jLabel3.setText("total price:");
		 container.add(jLabel3);
		 jLabel4.setBounds(30,200,120,30);
		 jLabel4.setForeground(Color.black);
		 jLabel4.setText("Input your address:");
		 container.add(jLabel4);
		 jt.setBounds(150,20,200, 30);
		 jt.setEditable(true);
		 container.add(jt);
		 jt1.setBounds(150,80,200, 30);
		 jt1.setEditable(true);
		 container.add(jt1);
		 jt2.setBounds(150,140,200, 30);
		 jt2.setEditable(false);
		 container.add(jt2);
		 jt3.setBounds(150,200,200, 30);
		 jt3.setEditable(true);
		 jt3.setText("please input your address");
		 container.add(jt3);
		 //按钮
		 JToggleButton jt_sure=new JToggleButton("确认");
		 JToggleButton jt_count=new JToggleButton("结算");
		 jt_plus.setBounds(350, 80, 50, 30);
		 jt_plus.setBackground(Color.lightGray);
		 container.add(jt_plus);
		 jt_dec.setBounds(410, 80, 50, 30);
		 jt_dec.setBackground(Color.lightGray);
		 container.add(jt_dec);
		 jt_sure.setBounds(330, 260, 60, 40);
		 jt_sure.setBackground(Color.lightGray);
		 container.add(jt_sure);
		 jt_count.setBounds(100, 260, 60, 40);
		 jt_count.setBackground(Color.lightGray);
		 container.add(jt_count);
		 //结算按钮的事件
		 jt_count.addActionListener(new ActionListener() {
		    	public void actionPerformed(ActionEvent e){
		    		String in=jt.getText();
		    	    int in1 = Integer.parseInt(in);
		    		String jn=jt1.getText();
		    		int jn1 = Integer.parseInt(jn); 
		    		if(in1==1){
		    			int price1=300;
		    			int total1=price1*jn1;
		    			String str1=total1+"";	
		    			jt2.setText(str1);
		    		}
		    		if(in1==2){
		    			int price2=200;
		    			int total2=price2*jn1;
		    			String str2=total2+"";	
		    			jt2.setText(str2);
		    		}
		    		if(in1==3){
		    			int price3=250;
		    			int total3=price3*jn1;
		    			String str3=total3+"";	
		    			jt2.setText(str3);
		    		}
		    		if(in1==4){
		    			int price4=350;
		    			int total4=price4*jn1;
		    			String str4=total4+"";	
		    			jt2.setText(str4);
		    		}
		    		if(in1==5){
		    			int price5=300;
		    			int total5=price5*jn1;
		    			String str5=total5+"";		
		    			jt2.setText(str5);
		    		}
		    		if(in1==6){
		    			int price6=150;
		    			int total6=price6*jn1;
		    			String str6=total6+"";		
		    			jt2.setText(str6);
		    		}
		    		if(in1==7){
		    			int price7=400;
		    			int total7=price7*jn1;
		    			String str7=total7+"";		
		    			jt2.setText(str7);
		    		}
		    		if(in1==8){
		    			int price8=180;
		    			int total8=price8*jn1;
		    			String str8=total8+"";	
		    			jt2.setText(str8);
		    		}
		    		if(in1==9){
		    			int price9=360;
		    			int total9=price9*jn1;
		    			String str9=total9+"";		
		    			jt2.setText(str9);
		    		}
		    		if(in1==10){
		    			int price10=340;
		    			int total10=price10*jn1;
		    			String str10=total10+"";		
		    			jt2.setText(str10);
		    		}
		    		if(in1==11){
		    			int price11=230;
		    			int total11=price11*jn1;
		    			String str11=total11+"";	
		    			jt2.setText(str11);
		    		}
		    		if(in1==12){
		    			int price12=150;
		    			int total12=price12*jn1;
		    			String str12=total12+"";	
		    			jt2.setText(str12);
		    		}
		    		if(in1>12||in1<0)
		    		{
		    			JOptionPane.showMessageDialog(null,"不好意思，你输入的商品不存在");
		    		}
		    	}
		      
		      });
		 
		 //确认按钮的事件监听
		 jt_sure.addActionListener(new ActionListener() {
		    	public void actionPerformed(ActionEvent e){
		    		String i=jt.getText();
		    		String j=jt1.getText();
		    		int i1 = Integer.parseInt(i); 
		    		int j1 = Integer.parseInt(j); 
		    		if(i1>0&&j1>0){
		    		JOptionPane.showMessageDialog(null,"购买成功~~我们将尽快发货");	
		    	}
		    		else{
		    			JOptionPane.showMessageDialog(null,"无效的ID和数量");	
		    		}
		    	}
		      
		      });
		 
		 //计数按钮(jt_plus)的事件监听
		 
		 jt_plus.addActionListener(new ActionListener() {
		    	public void actionPerformed(ActionEvent e){
		         String i=jt1.getText();
		       
		         int i1 = Integer.parseInt(i); 
		         if(i1<=0){
		        	 JOptionPane.showMessageDialog(null,"你输入的数量无效"); 
		        	 
		         }
		         else{
		         int i2=i1+1;
		         String iStr=String.valueOf(i2);
		         jt1.setText(iStr);
		    	}
		         }
		      
		      });
		 //减少按钮的事件监听
		 jt_dec.addActionListener(new ActionListener() {
		    	public void actionPerformed(ActionEvent e){
		         String i=jt1.getText();
		         int i1 = Integer.parseInt(i); 
		         if(i1<=0){
		        	 JOptionPane.showMessageDialog(null,"你输入的数量无效"); 
		        	 
		         }
		         else{
		         int i2=i1-1;
		         if(i2<=0){
		        	 JOptionPane.showMessageDialog(null,"不能再减少了");
		         }
		         else{
		         String iStr=String.valueOf(i2);
		         jt1.setText(iStr);
		         }
		    	}
		         }
		      
		      });
		 }

	public int getId() {
		return id;
	}

	public Map<Integer, Integer> getList() {
		return list;
	}

	public void setList(Map<Integer, Integer> list) {
		this.list = list;
	}
	//定义一个hashmap来充当购物车
	Map<Integer,Integer> map=new HashMap<>();
	//当用户想购买的时候，就加入购物车里面 
    public void addGoods(int id, int number) 
    { 
	       map.put(id, number); 
	        } 
	 //当用户不想要东西的时候，就把它删除 

    public void delGoods(int id) 
    { 
	map.remove(id); 
    } 
  //当用户什么也不想要的时候，就清空它 
    public void clearGoods() 
   { 
       map.clear(); 
   } 
  //当用户想更换物品的数量的时候，就更新一下 
    public void upGoods(int id, int newNumber) 
    { 
  //还是用加入物品的方法，因为会自动替换掉它，如果货物名字想换，那说明用户想删除了 
         map.put(id, newNumber); 
   } 
  //得到单个物品的数量,要用的话把它转成int型再使用 
    public int getGoodsNumberByGoodsId(int id) 
     { 
        return map.get(id);    
        } 
}
