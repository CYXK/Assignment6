package sale.pet.data;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

import com.mysql.jdbc.PreparedStatement;



public class DataBase {
	//jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456 
	

	String url = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
	

	public static ImageIcon[] imageIcon ={new ImageIcon("img/dog.jpg"),
		new ImageIcon("img/cat.jpg"),new ImageIcon("img/turtle.jpg"),new ImageIcon("img/parrot.jpg"),
		new ImageIcon("img/hamster.jpg"),new ImageIcon("img/squirrel.jpg"),new ImageIcon("img/rabbit.jpg"),
		new ImageIcon("img/snake.jpg"),new ImageIcon("img/lizard.jpg"),new ImageIcon("img/fish.jpg"),
		new ImageIcon("img/myna.jpg"),new ImageIcon("img/canary.jpg")
	};
	
	//��¼����ļ۸�
	public static int[] prices = {2099,2399,123,233,56,668,888,695,153,448,999,599};
	
	//�������Ʊ�ǩ
	public static JLabel[] labels = {new JLabel("����С��  ��"+prices[0]),new JLabel("����è  ��"+prices[1])
	,new JLabel("½ս��  ��"+prices[2]),new JLabel("��������  ��"+prices[3]),new JLabel("ѧ�Բ���  ��"+prices[4])
	,new JLabel("�ɰ�����  ��"+prices[5]),new JLabel("������  ��"+prices[6]),new JLabel("��������  ��"+prices[7])
	,new JLabel("̰�Ծ���  ��"+prices[8]),new JLabel("���㾫  ��"+prices[9]),new JLabel("�黨�˸�  ��"+prices[10])
	,new JLabel("�����˿ȸ  ��"+prices[11])
	};
	
	//��¼�����λ��
	public static Position[] position = {new Position(0,0),
		new Position(230,0),new Position(460,0),new Position(0,250),
		new Position(230,250),new Position(460,250)
	};
	
	public void update(int userId,String balance) {
		String sql = "UPDATE 2014302580196_user SET balance = ��"+balance+"�� WHERE id = "+userId+";";
		Connection connection = getConnection(url);
		PreparedStatement pstmt = null;
		int temp =0;
		try {
			pstmt = (PreparedStatement) connection.prepareStatement(sql);
			temp = pstmt.executeUpdate();
			pstmt.close();
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void write(String name,String password,
			String balance,String email) {
		String sql = "insert into 2014302580196_user (name,password,balance,email) values(?,?,?,?)";
		Connection connection = getConnection(url);
		PreparedStatement pstmt = null;
		
		try {
			pstmt = (PreparedStatement) connection.prepareStatement(sql);
			
				pstmt.setString(1, name);
				pstmt.setString(2, password);
				pstmt.setString(3, balance);
				pstmt.setString(4, email);
				pstmt.executeUpdate();
			pstmt.close();
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	private Connection getConnection(String url) {
		
		String driver = "com.mysql.jdbc.Driver";
		Connection connection = null;
		
		try {
			Class.forName(driver);
			
			connection =  DriverManager.getConnection(url);
			
		} catch (ClassNotFoundException e) {
			System.err.println("װ����������ʧ��!" );  
			e.printStackTrace();
		} catch (SQLException e) {
			System.err.println("�޷��������ݿ�!" ); 
			e.printStackTrace();
		}
		
		return connection;
	}
	
	public ArrayList<UserInfo> getUserInfo() {
		String sql = "select * from 2014302580196_user";
		ArrayList<UserInfo> myUserInfo = new ArrayList<UserInfo>();
		Statement statement;
		ResultSet resultSet;
		
		try {
			statement = getConnection(url).createStatement();
			resultSet = statement.executeQuery(sql);
			
			while(resultSet.next()) {
				String id = resultSet.getString(1);
				String name = resultSet.getString(2);
				String password = resultSet.getString(3);
				String balance = resultSet.getString(4);
				String email = resultSet.getString(5);
				
				UserInfo userInfo = new UserInfo(id,name,password,balance,email);
				myUserInfo.add(userInfo);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.err.println("�޷��������ݿ�" ); 
			e.printStackTrace();
		}
		
		return myUserInfo;
	}
	
	public ArrayList<PetInfo> getPetInfo() {
		String sql = "select * from 2014302580196_pet";
		ArrayList<PetInfo> myPetInfo = new ArrayList<PetInfo>();
		Statement statement;
		ResultSet resultSet;
		
		try {
			statement = getConnection(url).createStatement();
			resultSet = statement.executeQuery(sql);
			
			while(resultSet.next()) {
				String id = resultSet.getString(1);
				String name = resultSet.getString(2);
				String eat = resultSet.getString(3);
				String drink = resultSet.getString(4);
				String live = resultSet.getString(5);
				String hobby = resultSet.getString(6);
				
				PetInfo petInfo = new PetInfo(id,name,eat,drink,live,hobby);
				myPetInfo.add(petInfo);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.err.println("�޷��������ݿ�" ); 
			e.printStackTrace();
		}
		
		return myPetInfo;
	}

}
