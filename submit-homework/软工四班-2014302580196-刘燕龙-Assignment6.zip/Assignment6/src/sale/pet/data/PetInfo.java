package sale.pet.data;

public class PetInfo {
	public PetInfo(String id, String name, String eat, String drink,
					String live, String hobby) {
				super();
				this.id = id;
				this.name = name;
				this.eat = eat;
				this.drink = drink;
				this.live = live;
				this.hobby = hobby;
			}
			
			private String id;
			private String name;
			private String eat;
			private String drink;
			private String live;
			private String hobby;
			
			public String getId() {
				return id;
			}
			public void setId(String id) {
				this.id = id;
			}
			public String getName() {
				return name;
			}
			public void setName(String name) {
				this.name = name;
			}
			public String getEat() {
				return eat;
			}
			public void setEat(String eat) {
				this.eat = eat;
			}
			public String getDrink() {
				return drink;
			}
			public void setDrink(String drink) {
				this.drink = drink;
			}
			public String getLive() {
				return live;
			}
			public void setLive(String live) {
				this.live = live;
			}
			public String getHobby() {
				return hobby;
			}
			public void setHobby(String hobby) {
				this.hobby = hobby;
			}
			
			@Override
			public String toString() {
				return "PetInfo [id=" + id + ", name=" + name + ", eat=" + eat
						+ ", drink=" + drink + ", live=" + live + ", hobby="
						+ hobby + "]";
			}
}

