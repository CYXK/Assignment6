package sale.pet.data;

public class UserInfo {
	
	public UserInfo(String id, String name, String passWord, String balance,
			String email) {
		this.id = id;
		this.name = name;
		this.passWord = passWord;
		this.balance = balance;
		this.email = email;
	}
	
	private String id;
	private String name;
	private String passWord;
	private String balance;
	private String email;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassWord() {
		return passWord;
	}
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getBalance() {
		return balance;
	}
	public void setBalance(String balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "UserInfo [id=" + id + ", name=" + name + ", passWord="
				+ passWord + ", balance=" + balance + ", email=" + email + "]";
	}
	
}
