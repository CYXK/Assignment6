package sale.pet.ui;


import java.awt.Graphics;

import javax.swing.JPanel;

public class MyPanel extends JPanel{

	private static final long serialVersionUID = 1L;
	
	public MyPanel() {
		setLayout(null);
	}
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
	}

}
