package sale.pet.ui;


import java.awt.Dimension;


import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import sale.pet.data.DataBase;
import sale.pet.data.MyMailService;
import sale.pet.data.PetInfo;
import sale.pet.data.UserInfo;


/**
 * ����ϵͳ������
 * @author charles 2015/11/29
 *
 */
public class Entrance {
	
	JFrame frame = null;
	MyPanel helpPanel = null,petPanel = null,
	registerPanel = null,enterPanel = null,
			myInfoPanel = null,toEnterPanel = null,
			cartPanel = null,petInfoPanel = null;
	JTextField searchBar = null;
	JScrollPane jsp = null;
	JButton search = null,register = null,enter = null,my = null;
	
	
	Font font = null;
	
	JButton b1 = null;
	
	JButton back =null;
	
	DataBase db = new DataBase();
	ArrayList<PetInfo> myPet = db.getPetInfo();
	ArrayList<UserInfo> myUser = db.getUserInfo();
	MyMailService myService = new MyMailService();
	UserInfo currentUser = null;
	
	public Entrance() {
		frame = new JFrame("��������ƽ̨");
		
		
		font = new Font("����",Font.BOLD,15);
		
		helpPanel = new MyPanel();
		
		enter = new JButton("��¼");
		searchBar = new JTextField("������ϲ���ĳ����~");
		search = new JButton("����");
		register = new JButton("ע��");
		my = new JButton("�ҵ�");
		
		
		petPanel = new MyPanel();
	
	}
		
	//���س�ʼ������
	private void initialize() {
		frame.setLayout(null);
		frame.setBounds(200, 0, 800, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);		
		frame.setVisible(true);
		
		helpPanel.setBounds(0, 0, 800, 100);
		
		searchBar.setSize(400, 50);
		searchBar.setLocation(10,20);
		searchBar.setFont(font);
		helpPanel.add(searchBar);
		
		search.setSize(80,50);
		search.setLocation(420,20);
		search.setFont(font);
		helpPanel.add(search);
		
		register.setSize(80,50);
		register.setLocation(520,20);
		register.setFont(font);
		helpPanel.add(register);
		
		enter.setSize(90,50);
		enter.setLocation(610,20);
		enter.setFont(font);
		helpPanel.add(enter);
		
		my.setSize(80,50);
		my.setLocation(710,20);
		my.setFont(font);
		helpPanel.add(my);
		
		frame.add(helpPanel);
		
		
		final JLabel dog = new JLabel();
		dog.setIcon(DataBase.imageIcon[0]);
		dog.setBounds(40, 0, 200, 200);
		dog.addMouseListener(new MyListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(enter.getText().equals("��¼")) {
					setToEnterPanel();
					helpPanel.setVisible(false);
					jsp.setVisible(false);
				}else{
					
					setPetInfoPanel(0);
					helpPanel.setVisible(false);
					jsp.setVisible(false);
				}
				
			}
		});
		DataBase.labels[0].setBounds(40, 200, 200, 50);
		DataBase.labels[0].setFont(font);
		petPanel.add(DataBase.labels[0]);
		petPanel.add(dog);
		
		final JLabel cat = new JLabel();
		cat.setIcon(DataBase.imageIcon[1]);
		cat.setBounds(40, 250, 200, 200);
		cat.addMouseListener(new MyListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(enter.getText().equals("��¼")) {
					setToEnterPanel();
					helpPanel.setVisible(false);
					jsp.setVisible(false);
				}else{
					
					setPetInfoPanel(1);
					helpPanel.setVisible(false);
					jsp.setVisible(false);
				}
				
			}
		});
		petPanel.add(cat);
		DataBase.labels[1].setBounds(40, 450, 200, 50);
		DataBase.labels[1].setFont(font);
		petPanel.add(DataBase.labels[1]);
				
		final JLabel canary = new JLabel();
		canary.setIcon(DataBase.imageIcon[11]);
		canary.setBounds(40, 750, 200, 200);
		canary.addMouseListener(new MyListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(enter.getText().equals("��¼")) {
					setToEnterPanel();
					helpPanel.setVisible(false);
					jsp.setVisible(false);
				}else{
					
					setPetInfoPanel(11);
					helpPanel.setVisible(false);
					jsp.setVisible(false);
				}
				
			}
		});
		petPanel.add(canary);
		DataBase.labels[11].setBounds(40, 950, 200, 50);
		DataBase.labels[11].setFont(font);
		petPanel.add(DataBase.labels[11]);
		
		final JLabel fish = new JLabel();
		fish.setIcon(DataBase.imageIcon[9]);
		fish.setBounds(280, 0, 200, 200);
		fish.addMouseListener(new MyListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(enter.getText().equals("��¼")) {
					setToEnterPanel();
					helpPanel.setVisible(false);
					jsp.setVisible(false);
				}else{
					
					setPetInfoPanel(9);
					helpPanel.setVisible(false);
					jsp.setVisible(false);
				}
				
			}
		});
		petPanel.add(fish);
		DataBase.labels[9].setBounds(280, 200, 200, 50);
		DataBase.labels[9].setFont(font);
		petPanel.add(DataBase.labels[9]);
		
		final JLabel hamster = new JLabel();
		hamster.setIcon(DataBase.imageIcon[4]);
		hamster.setBounds(520, 0, 200, 200);
		hamster.addMouseListener(new MyListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(enter.getText().equals("��¼")) {
					setToEnterPanel();
					helpPanel.setVisible(false);
					jsp.setVisible(false);
				}else{
					
					setPetInfoPanel(4);
					helpPanel.setVisible(false);
					jsp.setVisible(false);
				}
				
			}
		});
		petPanel.add(hamster);
		DataBase.labels[4].setBounds(520, 200, 200, 50);
		DataBase.labels[4].setFont(font);
		petPanel.add(DataBase.labels[4]);
		
		final JLabel myna = new JLabel();
		myna.setIcon(DataBase.imageIcon[10]);
		myna.setBounds(280, 250, 200, 200);
		myna.addMouseListener(new MyListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(enter.getText().equals("��¼")) {
					setToEnterPanel();
					helpPanel.setVisible(false);
					jsp.setVisible(false);
				}else{
					
					setPetInfoPanel(10);
					helpPanel.setVisible(false);
					jsp.setVisible(false);
				}
				
			}
		});
		petPanel.add(myna);
		DataBase.labels[10].setBounds(280, 450, 200, 50);
		DataBase.labels[10].setFont(font);
		petPanel.add(DataBase.labels[10]);
		
		final JLabel parrot = new JLabel();
		parrot.setIcon(DataBase.imageIcon[3]);
		parrot.setBounds(520, 250, 200, 200);
		parrot.addMouseListener(new MyListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(enter.getText().equals("��¼")) {
					setToEnterPanel();
					helpPanel.setVisible(false);
					jsp.setVisible(false);
				}else{
					
					setPetInfoPanel(3);
					helpPanel.setVisible(false);
					jsp.setVisible(false);
				}
				
			}
		});
		petPanel.add(parrot);
		DataBase.labels[3].setBounds(520, 450, 200, 50);
		DataBase.labels[3].setFont(font);
		petPanel.add(DataBase.labels[3]);
		
		final JLabel rabbit = new JLabel();
		rabbit.setIcon(DataBase.imageIcon[6]);
		rabbit.setBounds(280, 500, 200, 200);
		rabbit.addMouseListener(new MyListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(enter.getText().equals("��¼")) {
					setToEnterPanel();
					helpPanel.setVisible(false);
					jsp.setVisible(false);
				}else{
					
					setPetInfoPanel(6);
					helpPanel.setVisible(false);
					jsp.setVisible(false);
				}
				
			}
		});
		petPanel.add(rabbit);
		DataBase.labels[6].setBounds(280, 700, 200, 50);
		DataBase.labels[6].setFont(font);
		petPanel.add(DataBase.labels[6]);
		
		final JLabel snake = new JLabel();
		snake.setIcon(DataBase.imageIcon[7]);
		snake.setBounds(520, 500, 200, 200);
		snake.addMouseListener(new MyListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(enter.getText().equals("��¼")) {
					setToEnterPanel();
					helpPanel.setVisible(false);
					jsp.setVisible(false);
				}else{
					
					setPetInfoPanel(7);
					helpPanel.setVisible(false);
					jsp.setVisible(false);
				}
				
			}
		});
		petPanel.add(snake);
		DataBase.labels[7].setBounds(520, 700, 200, 50);
		DataBase.labels[7].setFont(font);
		petPanel.add(DataBase.labels[7]);
		
		final JLabel lizard = new JLabel();
		lizard.setIcon(DataBase.imageIcon[8]);
		lizard.setBounds(40, 500, 200, 200);
		lizard.addMouseListener(new MyListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(enter.getText().equals("��¼")) {
					setToEnterPanel();
					helpPanel.setVisible(false);
					jsp.setVisible(false);
				}else{
					
					setPetInfoPanel(8);
					helpPanel.setVisible(false);
					jsp.setVisible(false);
				}
				
			}
		});
		petPanel.add(lizard);
		DataBase.labels[8].setBounds(40, 700, 200, 50);
		DataBase.labels[8].setFont(font);
		petPanel.add(DataBase.labels[8]);
		
		final JLabel squirrel = new JLabel();
		squirrel.setIcon(DataBase.imageIcon[5]);
		squirrel.setBounds(280, 750, 200, 200);
		squirrel.addMouseListener(new MyListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(enter.getText().equals("��¼")) {
					setToEnterPanel();
					helpPanel.setVisible(false);
					jsp.setVisible(false);
				}else{
					
					setPetInfoPanel(5);
					helpPanel.setVisible(false);
					jsp.setVisible(false);
				}
				
			}
		});
		petPanel.add(squirrel);
		DataBase.labels[5].setBounds(280, 950, 200, 50);
		DataBase.labels[5].setFont(font);
		petPanel.add(DataBase.labels[5]);
		
		final JLabel turtle = new JLabel();
		turtle.setIcon(DataBase.imageIcon[2]);
		turtle.setBounds(520, 750, 200, 200);
		turtle.addMouseListener(new MyListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(enter.getText().equals("��¼")) {
					setToEnterPanel();
					helpPanel.setVisible(false);
					jsp.setVisible(false);
				}else{
					
					setPetInfoPanel(2);
					helpPanel.setVisible(false);
					jsp.setVisible(false);
				}
				
			}
		});
		petPanel.add(turtle);
		DataBase.labels[2].setBounds(520, 950, 200, 50);
		DataBase.labels[2].setFont(font);
		petPanel.add(DataBase.labels[2]);
		
	
		petPanel.setPreferredSize(new Dimension(800,1000));
		jsp = new JScrollPane(petPanel);
		jsp.setSize(800, 500);
		jsp.setLocation(0,100);
		jsp.getVerticalScrollBar().setUnitIncrement(20);
		frame.add(jsp);
			
		mainEvent();
		
	}

	private void mainEvent() {
		
		search.addMouseListener(new MyListener() {
			public void mouseClicked(MouseEvent e) {
				String keyWord = searchBar.getText();
				
				if(keyWord.contains("dog")||keyWord.contains("��")) {
					setPetInfoPanel(0);
					helpPanel.setVisible(false);
					jsp.setVisible(false);
					
				}else if(keyWord.contains("cat")||keyWord.contains("è")) {
					setPetInfoPanel(1);
					helpPanel.setVisible(false);
					jsp.setVisible(false);
					
				}else if(keyWord.contains("turtle")||keyWord.contains("��")) {
					setPetInfoPanel(2);
					helpPanel.setVisible(false);
					jsp.setVisible(false);
					
				}else if(keyWord.contains("parrot")||keyWord.contains("����")) {
					setPetInfoPanel(3);
					helpPanel.setVisible(false);
					jsp.setVisible(false);
					
				}else if(keyWord.contains("hamster")||keyWord.contains("����")) {
					setPetInfoPanel(4);
					helpPanel.setVisible(false);
					jsp.setVisible(false);
					
				}else if(keyWord.contains("squirrel")||keyWord.contains("����")) {
					setPetInfoPanel(5);
					helpPanel.setVisible(false);
					jsp.setVisible(false);
					
				}else if(keyWord.contains("rabbit")||keyWord.contains("��")) {
					setPetInfoPanel(6);
					helpPanel.setVisible(false);
					jsp.setVisible(false);
					
				}else if(keyWord.contains("snake")||keyWord.contains("��")) {
					setPetInfoPanel(7);
					helpPanel.setVisible(false);
					jsp.setVisible(false);
					System.out.println(keyWord);
				}else if(keyWord.contains("lizard")||keyWord.contains("����")) {
					setPetInfoPanel(8);
					helpPanel.setVisible(false);
					jsp.setVisible(false);
					
				}else if(keyWord.contains("fish")||keyWord.contains("��")) {
					setPetInfoPanel(9);
					helpPanel.setVisible(false);
					jsp.setVisible(false);
					
				}else if(keyWord.contains("myna")||keyWord.contains("�˸�")) {
					setPetInfoPanel(10);
					helpPanel.setVisible(false);
					jsp.setVisible(false);
					
				}else if(keyWord.contains("canary")||keyWord.contains("ȸ")) {
					setPetInfoPanel(11);
					helpPanel.setVisible(false);
					jsp.setVisible(false);
					
				}else {
					searchBar.setText("��Ǹ~û���ҵ���س���");
				}
			}
		});
		
		register.addMouseListener(new MyListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setRegister();//=========================����ŵ���������޷���ʾ������
				helpPanel.setVisible(false);
				jsp.setVisible(false);

			}
		});
		
		enter.addMouseListener(new MyListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(enter.getText().equals("�ǳ�")) {
					helpPanel.setVisible(true);
					jsp.setVisible(true);

				}else {
					setEnter();//=========================����ŵ���������޷���ʾ������
					helpPanel.setVisible(false);
					jsp.setVisible(false);
					
				}
			}
		});
		
		my.addMouseListener(new MyListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(enter.getText().equals("�ǳ�")) {
					myInfoPanel.setVisible(true);
					helpPanel.setVisible(false);
					jsp.setVisible(false);
				}
				else {
					helpPanel.setVisible(false);
					jsp.setVisible(false);
					setToEnterPanel();
				}
			}
		});
		
		
		
	}
	


	//�������
	public static void main(String[] args) {
		Entrance entrance = new Entrance();
		entrance.initialize();
		
		
	}
	
	//���������Ϣ���
	private void setPetInfoPanel(final int pet) {

		petInfoPanel = new MyPanel();
		petInfoPanel.setBounds(0, 0, 800, 600);
		
		setBack(petInfoPanel);
		
		Font petInfoFont = new Font("����",Font.BOLD,20);
		
		JLabel img = new JLabel();
		img.setIcon(DataBase.imageIcon[pet]);
		img.setBounds(150, 100, 200, 200);
		petInfoPanel.add(img);
		
		JLabel name = new JLabel("name:  "+myPet.get(pet).getName());
		name.setBounds(370,100,250,20);
		name.setFont(petInfoFont);
		petInfoPanel.add(name);
		JLabel eat = new JLabel("eat:   "+myPet.get(pet).getEat());
		eat.setBounds(370,130,250,20);
		eat.setFont(petInfoFont);
		petInfoPanel.add(eat);
		JLabel drink = new JLabel("drink: "+myPet.get(pet).getDrink());
		drink.setBounds(370,160,250,20);
		drink.setFont(petInfoFont);
		petInfoPanel.add(drink);
		JLabel live = new JLabel("live:  "+myPet.get(pet).getLive());
		live.setBounds(370,190,350,20);
		live.setFont(petInfoFont);
		petInfoPanel.add(live);
		JLabel hobby = new JLabel("Hobby: "+myPet.get(pet).getHobby());
		hobby.setBounds(370,220,250,20);
		hobby.setFont(petInfoFont);
		petInfoPanel.add(hobby);
		JLabel price = new JLabel("price: "+"��"+DataBase.prices[pet]);
		price.setBounds(370,250,250,20);
		price.setFont(petInfoFont);
		petInfoPanel.add(price);
		
		JButton addCart = new JButton("�����ҵĹ��ﳵ");
		addCart.setBounds(370, 280, 150, 20);
		addCart.setFont(font);
		petInfoPanel.add(addCart);
		
		//���빺�ﳵ��ť�¼�
		addCart.addMouseListener(new MyListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				count++;
				if(count>6) {
					count = 6;
				}
				setCartPanel(pet);
				petInfoPanel.setVisible(false);
			}
		});
		
		frame.setTitle("��ϸ��Ϣ");
		frame.add(petInfoPanel);
		
		
	}
	
	/*
	 * ��JLabel���¼���ɵ�
	 * ����setCarPanel�ǿ���ɵ�
	 */
	//�չ��ﳵ���
	private void setCartPanel() {
		cartPanel = new MyPanel();
		cartPanel.setBounds(0, 0, 800, 600);
		
		setBack(cartPanel);
		
		frame.setTitle("�ҵĹ��ﳵ");
		frame.add(cartPanel);
	}
	
	int count = 0;
	Integer num = 0,money = 0;
	ArrayList<Integer> memory = new ArrayList<Integer>();
	ArrayList<JLabel> lbs = new ArrayList<JLabel>();
	ArrayList<JRadioButton> jrb = new ArrayList<JRadioButton>();
	private void setCartPanel(int pet) {
		cartPanel = new MyPanel();
		
		cartPanel.setBounds(0, 0, 800, 600);
		
		setBack(cartPanel);
		memory.add(pet);
		lbs.add(DataBase.labels[pet]);
		JRadioButton jb = new JRadioButton("����");
		jrb.add(jb);
		

		final JLabel number = new JLabel("������"+num.toString());
		number.setBounds(700,450,80,25);
		final JLabel total = new JLabel("��"+money.toString());
		total.setBounds(700,475,80,25);
		
		
		ArrayList<JLabel> imgs = new ArrayList<JLabel>();
		for(int i = 0;i < count;i++) {
			JLabel img = new JLabel();
			imgs.add(img);
		}
		
		for(int i = 0;i < count;i++) {	
			imgs.get(i).setIcon(DataBase.imageIcon[memory.get(i)]);
			imgs.get(i).setBounds(DataBase.position[i].getX(),
					DataBase.position[i].getY(), 200, 200);
			lbs.get(i).setBounds(DataBase.position[i].getX(),
					DataBase.position[i].getY()+200, 150, 50);
			jrb.get(i).setBounds(DataBase.position[i].getX()+150,
					DataBase.position[i].getY()+200, 80, 50);
			cartPanel.add(imgs.get(i));
			cartPanel.add(lbs.get(i));
			cartPanel.add(jrb.get(i));
			final int temp = i;
			jrb.get(i).addMouseListener(new MyListener() {
				@Override
				public void mouseClicked(MouseEvent e) {
					if(jrb.get(temp).isSelected()) {
						num++;
						money += DataBase.prices[memory.get(temp)];
						
					}else {
						num--;
						money -= DataBase.prices[memory.get(temp)];
						
					}
					number.setText("������"+num.toString());
					total.setText("����"+money.toString());
					cartPanel.add(number);
					cartPanel.add(total);
					cartPanel.updateUI();
					
					
				}
			});
			
		}
		
		final JLabel fail = new JLabel("���㣡");
		fail.setBounds(700,425,80,25);
		fail.setForeground(Color.RED);

		
		JButton pay = new JButton("����");
		pay.setBounds(700, 500, 80, 50);
		pay.setFont(font);
		cartPanel.add(pay);
		pay.addMouseListener(new MyListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int currentMoney = Integer.parseInt(currentUser.getBalance());
				int userId = Integer.parseInt(currentUser.getId());
				if(currentMoney<money){
					cartPanel.add(fail);
				}else{
					currentUser.setBalance(String.valueOf(currentMoney-money));
					db.update(userId, currentUser.getBalance());
				}
			}
		});
		
		frame.setTitle("�ҵĹ��ﳵ");
		frame.add(cartPanel);
	}
	
	//δ��¼ʱ�ĸ�����Ϣ���
	private void setToEnterPanel() {
		toEnterPanel = new MyPanel();
		toEnterPanel.setBounds(0, 0, 800, 600);
		
		setBack(toEnterPanel);
		
		final JButton toEnter = new JButton("���Ҽ��ٵ�¼");
		toEnter.setBounds(320, 200, 150, 50);
		toEnter.setFont(font);
		toEnterPanel.add(toEnter);
		
		JLabel hint = new JLabel("��Ǹ~����û��¼");
		hint.setFont(font);
		hint.setBounds(330, 150, 150, 50);
		toEnterPanel.add(hint);
		
		frame.add(toEnterPanel);
		
		toEnter.addMouseListener(new MyListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setEnter();
				toEnterPanel.setVisible(false);
			}
		});
	}
	
	//��¼�������Ϣ���
	private void setMyInfoPanel(int userId) {
		myInfoPanel = new MyPanel();
		myInfoPanel.setBounds(0, 0, 800, 600);
		
		setBack(myInfoPanel);
		
		JLabel user = new JLabel("�˺ţ�"+myUser.get(userId-1).getName());
		JLabel balance = new JLabel("��"+myUser.get(userId-1).getBalance());
		JLabel rechargeL = new JLabel("��ֵ��");
		JLabel withdrwaL = new JLabel("����");
		//JLabel balance  = new JLabel("998");
		user.setBounds(300, 100, 100, 50);
		user.setFont(font);
		myInfoPanel.add(user);
		balance.setBounds(300, 150, 100, 50);
		balance.setFont(font);
		myInfoPanel.add(balance);
		
		JLabel cart = new JLabel("�ҵĹ��ﳵ");
		cart.setFont(font);
		cart.setBounds(300,200,100,50);
		myInfoPanel.add(cart);
	
		cart.addMouseListener(new MyListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(count == 0) {
					setCartPanel();
					myInfoPanel.setVisible(false);
				}else {
					cartPanel.setVisible(true);
				}

				myInfoPanel.setVisible(false);
			}
		});
		
		frame.add(myInfoPanel);
	}
	
	//��¼���
	JButton toRegister = null;
	JButton logIn = null;
	public void setEnter() {
		enterPanel = new MyPanel();
		enterPanel.setBounds(0, 0, 800, 600);
		
		
		JLabel title = new JLabel("��¼");
		title.setFont(new Font("����",Font.BOLD,30));
		title.setBounds(370, 30, 100, 50);
		enterPanel.add(title);
		
		JLabel userL = new JLabel("�˺ţ�");
		JLabel passWordL = new JLabel("���룺");
		
		userL.setBounds(250, 150, 80, 50);
		userL.setFont(font);
		enterPanel.add(userL);
		passWordL.setBounds(250, 230, 80, 50);
		passWordL.setFont(font);
		enterPanel.add(passWordL);
		
		final JLabel hint = new JLabel("�˺Ż��������");
		hint.setBounds(350,100,150,30);
		hint.setFont(new Font("����",Font.BOLD,15));
		hint.setForeground(Color.RED);
		
		final JTextField user = new JTextField();
		final JPasswordField password = new JPasswordField();
		user.setBounds(330, 150, 180, 50);
		user.setFont(font);
		enterPanel.add(user);
		password.setBounds(330, 230, 180, 50);
		enterPanel.add(password);

		toRegister = new JButton("����ע��");
		logIn = new JButton("���ҵ�¼");
		toRegister.setBounds(250, 300, 130, 50);
		toRegister.setFont(font);
		enterPanel.add(toRegister);
		logIn.setBounds(400, 300, 130, 50);
		logIn.setFont(font);
		enterPanel.add(logIn);
		logIn.addMouseListener(new MyListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String p = new String(password.getPassword());
				boolean b = false;
				int userId = 0;
				for(UserInfo u:myUser) {
					if(u.getName().equals(user.getText())&&u.getPassWord().equals(p)){
						b = true;
						currentUser = u;
						userId = Integer.parseInt(u.getId());
					}
				}
				if(b) {
					setMyInfoPanel(userId);
					enter.setText("�ǳ�");
					enterPanel.setVisible(false);
					
				}else{
					enterPanel.add(hint);
					enterPanel.updateUI();
				}
			}
		});
		
		setBack(enterPanel);
		
		frame.add(enterPanel);
		
		enterEvent();
	}
	
	private void enterEvent() {
		toRegister.addMouseListener(new MyListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
				helpPanel.setVisible(false);
				petPanel.setVisible(false);
				enterPanel.setVisible(false);
				
				setRegister();
			}
		});
		

		
	}


	//ע�����
	public void setRegister() {
		registerPanel = new MyPanel();
		registerPanel.setBounds(0, 0, 800, 600);
		
		JLabel title = new JLabel("ע���˻�");
		title.setFont(new Font("����",Font.BOLD,20));
		title.setBounds(320, 30, 100, 50);
		registerPanel.add(title);
		
		
		setBack(registerPanel);
		
		JLabel userL = new JLabel("�û�����");
		JLabel passwordL = new JLabel("��¼���룺");
		JLabel confirmPasswordL = new JLabel("ȷ�����룺");
		JLabel emailL = new JLabel("���䣺");
		
		Font sFont = new Font("����",Font.BOLD,12);
		
		userL.setFont(sFont);
		userL.setBounds(220, 100, 80, 30);
		registerPanel.add(userL);
		passwordL.setFont(sFont);
		passwordL.setBounds(220, 150, 80, 30);
		registerPanel.add(passwordL);
		confirmPasswordL.setFont(sFont);
		confirmPasswordL.setBounds(220, 200, 80, 30);
		registerPanel.add(confirmPasswordL);
		emailL.setFont(sFont);
		emailL.setBounds(220, 250, 80, 30);
		registerPanel.add(emailL);
		
		
		JLabel userInfo = new JLabel("����С��10���ַ�");
		final JLabel authInfo = new JLabel("��֤�����");
		final JLabel confirmInfo = new JLabel("ȷ���������");
		final JLabel conInfo = new JLabel("û�й�ѡ��");
		
		userInfo.setBounds(500, 100, 150, 30);
		userInfo.setFont(sFont);
		registerPanel.add(userInfo);
		confirmInfo.setBounds(500, 200, 150, 30);
		confirmInfo.setFont(sFont);
		confirmInfo.setForeground(Color.RED);
		conInfo.setBounds(500,350,150,30);
		conInfo.setFont(sFont);
		conInfo.setForeground(Color.RED);
		authInfo.setBounds(550,300,150,30);
		authInfo.setFont(sFont);
		authInfo.setForeground(Color.RED);
		
		final JTextField name = new JTextField("һ�����ò��ɸ��ģ�");
		final JPasswordField password = new JPasswordField();
		final JPasswordField confirmPassword = new JPasswordField();
		final JTextField email = new JTextField("����ȷ��д�Ա���֤��");
		
		name.setBounds(280, 100, 200, 30);
		name.setFont(sFont);
		registerPanel.add(name);
		password.setBounds(280, 150, 200, 30);
		registerPanel.add(password);
		confirmPassword.setBounds(280, 200, 200, 30);
		registerPanel.add(confirmPassword);
		email.setBounds(280, 250, 200, 30);
		email.setFont(sFont);
		registerPanel.add(email);
		
		final JTextField verification = new JTextField("��鿴��������");
		verification.setBounds(280,300,100,30);
		verification.setFont(sFont);
		registerPanel.add(verification);
		
		JButton getCode = new JButton("��ȡ��֤��");
		getCode.setBounds(380, 300, 100, 30);
		getCode.setFont(sFont);
		registerPanel.add(getCode);
		
	
		//��ȡ��֤����¼�
		getCode.addMouseListener(new MyListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
//				 String auth =
			setAuth( myService.getAuth(email.getText()));
			}
		});
		
		
		final JRadioButton confirm = new JRadioButton("�����Ķ���ͬ���������Э��Լ��");
		confirm.setBounds(280,350,220,30);
		confirm.setFont(sFont);
		registerPanel.add(confirm);
		
		JButton submit = new JButton("�ύ");
		submit.setBounds(280,400,100,50);
		submit.setFont(font);
		registerPanel.add(submit);
		final JLabel success = new JLabel("��ϲ�㣡ע��ɹ�!");
		success.setBounds(300,450,150,30);
		success.setFont(sFont);
		
		
		//�ύ��ť�ĵ���¼�
		submit.addMouseListener(new MyListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String s1 = new String(password.getPassword());
				String s2 = new String (confirmPassword.getPassword());
				
				registerPanel.remove(confirmInfo);
				registerPanel.remove(conInfo);
				registerPanel.remove(authInfo);
			
				if(s1.equals("")||!(s1.equals(s2))) {
					registerPanel.add(confirmInfo);
					registerPanel.updateUI();
				}else if(!confirm.isSelected()) {
					registerPanel.add(conInfo);
					registerPanel.updateUI();
				}else if(!(verification.getText().equals(getAuth()))) {
					registerPanel.add(authInfo);
					registerPanel.updateUI();
				}else {
					registerPanel.add(success);
					registerPanel.updateUI();
					db.write(name.getText(), s1, email.getText(), "10000");
				}
			}
		});
		
		final JButton toEnterPanel = new JButton("ֱ�ӵ�¼");
		toEnterPanel.setBounds(380,400,100,50);
		toEnterPanel.setFont(font);
		registerPanel.add(toEnterPanel);
		toEnterPanel.addMouseListener(new MyListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setEnter();
				registerPanel.setVisible(false);
			}
		});
		

		frame.add(registerPanel);
	}
	String auth;
	public void setAuth(String auth) {
		this.auth = auth;
	}
	public String getAuth() {
		return auth;
	}


	//���÷��ذ�ť
	private void setBack(final JPanel panel) {
		// TODO Auto-generated method stub
		back = new JButton("����");
		back.setFont(font);
		back.setBounds(720, 0, 80, 50);
		panel.add(back);
		back.addMouseListener(new MyListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.setTitle("��������ƽ̨");
				helpPanel.setVisible(true);
				petPanel.setVisible(true);
				jsp.setVisible(true);
//				if(panel == cartPanel) 
					back.setVisible(false);
				panel.setVisible(false);
					
			}
		});

	}
	
	/**
	 * �Զ�����������
	 */
	private class MyListener implements MouseListener {

		@Override
		public void mouseClicked(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
		
	}
} 
